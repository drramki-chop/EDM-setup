#' @export
#' @importFrom yaml  read_yaml
#' @importFrom dplyr filter
#' @importFrom magrittr "%>%"
#' @importFrom clustermq Q
wrapper.script <- function(input){ 
  ## read yaml file  
  input.yaml <- yaml::read_yaml(input)
  
  ## create directories
  system(paste0("mkdir -p ",input.yaml$output.directory,"/coverage"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/logs"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results/individual.edm.calls/"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results/individual.ed.objects/"))
  ##check and  read  manifest
  if(is.null(input.yaml[["manifest"]])){
    message('Cannot proceed without a  manifest. Please look at the sample manifest provided in the documentation.\n')
    break;
  }else if(!is.null(input.yaml[["manifest"]]) & file.exists(input.yaml$manifest)){
    message('Reading the manifest...')
    manifest <- read.table(input.yaml$manifest, header = T, sep ="\t", stringsAsFactors = F)
    names(manifest) <- c("bam","sampleID","sex")
    
    nSamples <- NROW(manifest)
    nFemales <- NROW(manifest[manifest$sex == "M",])
    nMales <- NROW(manifest[manifest$sex == "F",])
    
    message(paste0('Found:\n * ',
                   nSamples,' individuals (',
                   nMales,' Males and ',nFemales,' females.)\n'))
    
  }else if(sum(is.na(manifest)) > 0){
    # check for empty entries in the manifest
    message('Entries in manifest cannot be empty. Please check your manifest before running.\n');
    break;
  }
  
  # Check for duplicate individual IDs
  if(sum(duplicated(sort(manifest$sampleID))) > 0){
    message('Found these duplicates in individual IDs\n', manifest$sampleID[duplicated(manifest$sampleID)] );
    break;
  }
  
  ## check bam files
  message('Checking the bam files...\n');
  if(sum(file.exists(as.character(manifest$bam))) < length(manifest$bam)){
    message('List of missing bam files:\n\n');
    print(paste(manifest$bam[!file.exists(as.character(manifest$bam))],"\n"))
    stop('Looks like some of your bam files are missing. Check your bam paths.\n\n\n')
  }
  
  ## check for index files
  message('Checking the index files for bams...\n');
  manifest$bai <- NA;
  manifest$bai[which(file.exists(paste0(as.character(manifest$bam),".bai")))] <- paste0(as.character(manifest$bam[which(file.exists(paste0(as.character(manifest$bam),".bai")))]),".bai")
  manifest$bai[which(file.exists(paste0(gsub(pattern = "bam","bai",manifest$bam))))] <- paste0(gsub(pattern = "bam","bai",manifest$bam[which(file.exists(paste0(gsub(pattern = "bam","bai",manifest$bam))))]))
  message(paste0('Samples with missing index files are written to results/missing.index.samples.txt \n sample_names:')) 
  message(paste0(manifest$sampleID[is.na(manifest$bai)],'\n'));
  write.table( paste0('Index file not found for ',manifest[is.na(manifest$bai),]),paste0(input.yaml$output.directory,"/results/missing.index.samples.txt"),row.names=F,quote=F, sep ="\t") 
  manifest <- manifest[!is.na(manifest$bai),]
  write.table(manifest[,1:3],paste0(input.yaml$output.directory,"/results/",input.yaml$manifest),row.names =F,quote =F, sep ="\t")

  # for (i in 1:length(manifest$bam)){
  #  if(file.exists(gsub(pattern = "bam","bai",manifest$bam[i]))){
  #    manifest$bai[i] <- gsub(pattern = "bam","bai",manifest$bam[i])
  #  } else if(file.exists(paste0(as.character(manifest$bam[i]),".bai"))){
  #    manifest$bai[i] <- paste0(as.character(manifest$bam[i]),".bai")
  #  } else{
  #    message(paste0('Samples with missing index files are written to temp/missing.index.samples.txt\n'));
  #    write.table( paste0('Index file not found for ',manifest$bam[i]),paste0(input.yaml$output.directory,"/temp/missing.index.samples.txt"),row.names=F,quote=F)
      ## Edit manifest based on index
  #    manifest <- manifest[
  #  }
  #}
 
 
  ## edit this based on cluster template
  ## clustermq template
  if(is.null(input.yaml[["hpc.scheduler"]])){
    message('Cannot proceed without a Scheduler type\n')
    break;
  }else{
    if(is.null(input.yaml[["clustermq.template"]])){ 
      options(
        clustermq.scheduler = paste0(input.yaml$hpc.scheduler),
        clustermq.template = paste0(find.package("EDM"),"/template/",input.yaml$hpc.scheduler,"_template"),
        clustermq.defaults = list(conda="edm_env")
      )
    } else {
      options(
        clustermq.scheduler = paste0(input.yaml$hpc.scheduler),
        clustermq.template = paste0(input.yaml$clustermq.template),
        clustermq.defaults = list(conda="edm_env")
      )
    }
  }
  
  
  EDM::check.exons.def(input=input)
  
  ## get Counts step
  #  source("clustermq_getCounts.R")
  nSamples = NROW(manifest)
  message(' Count step...   \n')
  clustermq::Q(get.bam.counts.mosdepth,pkgs="EDM",task_id=1:nSamples,input = input,n_jobs=nSamples, max_calls_worker = 1, template=list(job_name="compute_coverage",memory = (input.yaml$memory*1024), mem = paste0(input.yaml$memory,"G")),export = list(input = input))
  
  ## move log files
  system(paste0("mv compute_coverage* ",input.yaml$output.directory,"/logs/."))
  
  ## gather counts
  message(' Gathering Counts...   \n')
  clustermq::Q(gather.mosdepth.coverage,pkgs="EDM",task_id=1,input = input,n_jobs=1, max_calls_worker = 1,template=list(job_name="gather_coverage",memory = (input.yaml$memory*1024), mem = paste0(input.yaml$memory,"G")), export = list(input = input))
  
  #  source("gather_counts.R") 
  ## move log files
  system(paste0("mv gather_coverage* ",input.yaml$output.directory,"/logs/."))
  
  ## call variants
  message('Calling variants...   \n')
  clustermq::Q(call.variants,pkgs=list("EDM","ExomeDepth"),columnIndex=1:nSamples,n_jobs=nSamples,input=input, max_calls_worker = 1,template=list(job_name="call_variants",memory = (input.yaml$memory*1024), mem = paste0(input.yaml$memory,"G")), export = list(input = input))
  
  ## move log files
  system(paste0("mv call_variants* ",input.yaml$output.directory,"/logs/."))
  
  ## gather variants
  message(' Gathering Calls...   \n')
  clustermq::Q(gather.variant.calls,pkgs=list("EDM"),task_id=1,input = input,n_jobs=1, max_calls_worker = 1,template=list(job_name="gather_calls",memory = (input.yaml$memory*1024), mem = paste0(input.yaml$memory,"G")), export = list(input = input))
  system(paste0("mv gather_calls* ",input.yaml$output.directory,"/logs/."))

  message(' Plotting correlation...   \n')
  clustermq::Q(plot.sample.max.correlation,pkgs=list("EDM"),input = input,n_jobs=1, max_calls_worker = 1,template=list(job_name="plotting_correlation",memory = (input.yaml$memory*1024), mem = paste0(input.yaml$memory,"G")), export = list(input = input))

  system(paste0("mv plotting_correlation* ",input.yaml$output.directory,"/logs/."))
  system(paste0("rm ",input.yaml$output.directory,"/results/individual.edm.calls/*.edm.cor.txt"))
  
  ## summary data
  cohort.summary <- read.table(paste0(input.yaml$output.directory,"/results/",input.yaml$cohort.name,".edm.summary.cohort.txt"),header=T,stringsAsFactors=F)
   
  ## summary
  message('Summary of number of calls in cohort \n')
  message('Mean of cohort: ',round(mean(cohort.summary$Freq)),'\n')
  message('Mean of cohort: ',median(cohort.summary$Freq),'\n')
  message('Min calls: ',min(cohort.summary$Freq),' Max calls:',max(cohort.summary$Freq),'\n')
  message('Standard deviation: ',paste0(sd(cohort.summary$Freq),'\n'))
  return(message('Pipeline ran to complete'))
}   
