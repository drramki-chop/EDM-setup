wrapper.script <- function(input){ 
  
  ## read yaml file  
  input.yaml <- yaml::read_yaml(input)
  
  ##check and  read  manifest
  if(is.null(input.yaml[["manifest"]])){
    message('Cannot proceed without a  manifest. Please look at the sample manifest provided in the documentation.\n')
    break;
  }else if(!is.null(input.yaml[["manifest"]]) & file.exists(input.yaml$manifest)){
    message('Reading the manifest...')
    manifest <- read.table(input.yaml$manifest, header = T, sep ="\t", stringsAsFactors = F)
    names(manifest) <- c("bam","sampleID","sex")
    
    nSamples <- NROW(manifest)
    nFemales <- NROW(manifest[manifest$sex == "M",])
    nMales <- NROW(manifest[manifest$sex == "F",])
    
    message(paste0('Found:\n * ',
                   nSamples,' individuals (',
                   nMales,' Males and ',nFemales,' females.)\n'))
    
  }else if(sum(is.na(manifest)) > 0){
    # check for empty entries in the manifest
    message('Entries in manifest cannot be empty. Please check your manifest before running.\n');
    break;
  }
  
  # Check for duplicate individual IDs
  if(sum(duplicated(sort(manifest$sampleID))) > 0){
    message('Found these duplicates in individual IDs\n', manifest$sampleID[duplicated(manifest$sampleID)] );
    break;
  }
  
  ## check bam files
  message('Checking the bam files...\n');
  if(sum(file.exists(as.character(manifest$bam))) < length(manifest$bam)){
    message('List of missing bam files:\n\n');
    print(paste(manifest$bam[!file.exists(as.character(manifest$bam))],"\n"))
    stop('Looks like some of your bam files are missing. Check your bam paths.\n\n\n')
  }
  
  ## check for index files
  message('Checking the index files for bams...\n');
  manifest$bai <- NA;
  for (i in 1:length(manifest$bam)){
    if(file.exists(gsub(pattern = "bam","bai",manifest$bam[i]))){
      manifest$bai[i] <- gsub(pattern = "bam","bai",manifest$bam[i])
    } else if(file.exists(paste0(as.character(manifest$bam[i]),".bai"))){
      manifest$bai[i] <- paste0(as.character(manifest$bam[i]),".bai")
    } else{
      message(paste0('Index file not found for ',manifest$bam[i],"\n"));
      break;
    }
  }
  
  ## edit this based on cluster template
  ## clustermq template
  if(is.null(input.yaml[["hpc.scheduler"]])){
    message('Cannot proceed without a Scheduler type\n')
    break;
  }else{
    if(is.null(input.yaml[["clustermq.template"]])){ 
      options(
        clustermq.scheduler = paste0(input.yaml$hpc.scheduler),
        clustermq.template = paste0(find.package("EDM"),"/template/",input.yaml$hpc.scheduler,"_template"),
        clustermq.defaults = list(conda="edm_env")
      )
    } else {
      options(
        clustermq.scheduler = paste0(input.yaml$hpc.scheduler),
        clustermq.template = paste0(input.yaml$clustermq.template),
        clustermq.defaults = list(conda="edm_env")
      )
    }
  }
  
  
  system(paste0("mkdir -p ",input.yaml$output.directory,"/coverage"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/logs"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/temp")) 
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results/individual.edm.calls/"))
  system(paste0("mkdir -p ",input.yaml$output.directory,"/results/individual.ed.objects/"))

  EDM::check.exons.def(input=input)
  
  ## get Counts step
  #  source("clustermq_getCounts.R")
  nSamples = NROW(manifest)
  message(' Count step...   \n')
  clustermq::Q(get.bam.counts.mosdepth,pkgs="EDM",task_id=1:nSamples,input = input,n_jobs=nSamples, max_calls_worker = 1, template=list(job_name="compute_coverage"),export = list(input = input))
  
  ## move log files
  system(paste0("mv compute_coverage* ",input.yaml$output.directory,"/logs/."))
  
  ## gather counts
  message(' Gathering Counts...   \n')
  clustermq::Q(gather.mosdepth.coverage,pkgs="EDM",task_id=1,input = input,n_jobs=1, max_calls_worker = 1,template=list(job_name="gather_coverage"), export = list(input = input))
  
  #  source("gather_counts.R") 
  ## move log files
  system(paste0("mv gather_coverage* ",input.yaml$output.directory,"/logs/."))
  
  ## call variants
  message('Calling variants...   \n')
  clustermq::Q(call.variants,pkgs=list("EDM","ExomeDepth"),columnIndex=1:nSamples,n_jobs=nSamples,input=input, max_calls_worker = 1,template=list(job_name="call_variants"), export = list(input = input))
  
  ## move log files
  system(paste0("mv call_variants* ",input.yaml$output.directory,"/logs/."))
  
  ## gather variants
  message(' Gathering Calls...   \n')
  clustermq::Q(gather.variant.calls,pkgs=list("EDM"),task_id=1,input = input,n_jobs=1, max_calls_worker = 1,template=list(job_name="gather_calls"), export = list(input = input))
  system(paste0("mv gather_calls* ",input.yaml$output.directory,"/logs/."))
  return(message('Pipeline ran to complete'))
}
