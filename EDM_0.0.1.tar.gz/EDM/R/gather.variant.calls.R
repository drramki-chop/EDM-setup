gather.variant.calls <- function(task_id,input){

input.yaml <- yaml::read_yaml(input)

cnvFiles <- list.files(paste0(input.yaml$output.directory,"/results/individual.edm.calls/"),pattern = "*.edm.calls.txt")

# calls <- purrr::map_dfc(cnvFiles, function(x) {data.table::fread(x)}) 

calls <- do.call(rbind,lapply(cnvFiles, function(fn) read.table(file.path(paste0(fn)),header=T,stringsAsFactors=F )))

write.table(calls,paste0(input.yaml$output.directory,"/results/",input.yaml$cohort.name,".edm.cohort.calls.txt"),row.names=F,sep="\t",quote=F)
}
