#' @importFrom magrittr %>%
#' @importFrom yaml read_yaml
#' @importFrom purrr map_dfc

gather.mosdepth.coverage <- function(task_id,input){
  source("helper_file.R")
#  input.yaml <- yaml::read_yaml("input.yaml")
  coverageFolder <- paste0(input.yaml$outputDir,"/coverage/");
  cohort.name <- input.yaml$cohort.name;

  countFiles <- list.files(path=coverageFolder,pattern = "*.regions.bed.gz$",full.names=T)
  snames <- list.files(path=coverageFolder,pattern = "*.regions.bed.gz$")
  snames <- gsub(".regions.bed.gz","",snames)
  
  ### check file sizes
  fileSizes <- unlist(lapply(countFiles,file.size))
  if(sum(fileSizes == 0) > 0){
    failedSamples <- countFiles[which(fileSizes ==0)]
    countFiles <- countFiles[-which(fileSizes ==0)]
    snames <- snames[-which(fileSizes ==0)]
    write.table(failedSamples,paste0(input.yaml$outputDir,"/results/",cohort.name,".samples.failed.coverage.txt"),quote=F,row.names=F)
    message(paste0("Wrote failed samples to the file ",cohort.name,".samples.failed.coverage.txt. Proceeding with the rest of the samples"))
  }
  
  if(length(countFiles) > 0){
    firstSample <- as.data.frame(data.table::fread(countFiles[1]))
    nCols <- dim(firstSample)[2]
    
    names(firstSample)[nCols] <- snames[1]
    snames <- snames[-1]
    annotations <- firstSample[,1:(nCols-1)]
    names(annotations)[1:3] <- c("chromosome","start","end")
    annotations$name <- paste0(annotations$chromosome,":",annotations$start,"-",annotations$end)
    
    countFiles <- countFiles[-1];
    firstSample <- round(firstSample[,nCols,drop=F])
    
    counts <- purrr::map_dfc(countFiles, function(x) {round(data.table::fread(x,drop=1:(nCols-1)))})
    
    names(counts) <- snames
    countmat <- as.matrix(cbind(firstSample,counts))
    
    selected.exons <- select.exons(cohort.counts = countmat,bin.length = (annotations$end-annotations$start)/1000,n.bins.reduced = 10000)
    countmat.selected <- countmat[selected.exons,]
    
    countmat.cor <- cor(countmat.selected)
    countData <- list(countmat = countmat, 
                      annotations=annotations, 
                      selected.exons=selected.exons,
                      correlations = countmat.cor)
    
    saveRDS(countData,file=paste0(input.yaml$outputDir,"/results/",cohort.name,".exomedepth.cohort.rds"))
  }
}
