

mappability <- function(input){
  
  ## read yaml file  
  input.yaml <- yaml::read_yaml(input)
  bwAvg.exe <- system("which bigWigAverageOverBed", intern=T);
 
  ## bed-file
  if(is.null(input.yaml[["mappability"]])| input.yaml[["mappability"]] ==F  ){
    if(is.null(input.yaml[["bed.file"]]) | length(input.yaml[["bed.file"]])==0 ){
      data(exons.hg19,package = "ExomeDepth")
      data(exons.hg19.X,package = "ExomeDepth")
      exons <- rbind(exons.hg19,exons.hg19.X)
      
      write.table(exons[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
      exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed") 
    } else {
      if(tools::file_ext(input.yaml$bed.file)=="rds"){
        exons = readRDS(input.yaml$bed.file)
        if (dim(exons)[2] == 3){
          names(exons) <- c("chromosome","start","end")
        } else {
          names(exons) <- c("chromosome","start","end","name")
          exons$chromosome <- gsub("chr","",exons$chromosome)
          
          write.table(exons[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
          exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed")
        }
        
      } else{
        exons <- read.table(input.yaml$bed.file,header = F)
        if (dim(exons)[2] == 3){
          names(exons) <- c("chromosome","start","end")
        } else {
          names(exons) <- c("chromosome","start","end","name")
        }
        exons$chromosome <- gsub("chr","",exons$chromosome)
        
        write.table(exons[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
        exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed")
      }
    }
  } else {
    if(is.null(input.yaml$mappability.file) | length(input.yaml$mappability.file)==0){
      message('Please provide mappability file. Download from here: wget http://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeMapability/wgEncodeCrgMapabilityAlign36mer.bigWig ...\n');
    } else {
      if(tools::file_ext(input.yaml$mappability.file)=="bigWig"){
        message('Mappability step... \n');
        if(is.null(input.yaml[["bed.file"]])| length(input.yaml[["bed.file"]])==0){
          data(exons.hg19,package = "ExomeDepth")
          data(exons.hg19.X,package = "ExomeDepth")
          exons <- rbind(exons.hg19,exons.hg19.X)
          exons$chromosome <- paste0("chr",exons$chromosome)
          i = 1
          while(length(which(duplicated(exons$name))) >0) { 
            exons$name[duplicated(exons$name)] <- paste0( exons$name[duplicated(exons$name)],"_dup",i)
            i = i+1 
          }
          write.table(exons,paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F, col.names=F) 
          system(paste0(bwAvg.exe," ",input.yaml$mappability.file," ",input.yaml$output.directory,"/temp/bed_file.bed ",input.yaml$output.directory,"/temp/map_coverage.tab"))
          message(paste0('Mappability results written to ',input.yaml$output.directory,'/temp/map_coverage.tab  \n'))
          
          foo <- read.table(paste0(input.yaml$output.directory,"/temp/map_coverage.tab"),stringsAsFactors=F)
          exons %>% filter(name %in% (foo %>% filter(V5 >= 0.7) %>% pull(1))) -> exons_1
          exons %>% filter(name %in% (foo %>% filter(V5 < 0.7) %>% pull(1))) -> exons_excluded
          
          exons_1$chromosome <- gsub("chr","",exons_1$chromosome) 
          write.table(exons_1[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
          message(paste0('Exons with low mappability written to ',input.yaml$output.directory,'temp/excluded_exons.bed  \n'))
          write.table(exons_excluded,paste0(input.yaml$output.directory,"/temp/excluded_exons.bed"),row.names =F,sep="\t",quote=F,col.names=F)
          exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed")
        } else {
          if(tools::file_ext(input.yaml$bed.file)=="rds"){
            exons = readRDS(input.yaml$bed.file)
            if (dim(exons)[2] == 3){
              message('Found only 3 columns in ',input.yaml$bed.file,' file. Need 4th Column.\n')
            } else {
              names(exons) <- c("chromosome","start","end","name")
              exons$chromosome <- gsub("chr","",exons$chromosome)
              exons$chromosome <- paste0("chr",exons$chromosome)
              i = 1
              while(length(which(duplicated(exons$name))) >0) {
                exons$name[duplicated(exons$name)] <- paste0( exons$name[duplicated(exons$name)],"_dup",i)
                i = i+1
              }
              write.table(exons,paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F, col.names=F) 
              system(paste0(bwAvg.exe," ",input.yaml$mappability.file," ",input.yaml$output.directory,"/temp/bed_file.bed ",input.yaml$output.directory,"/temp/map_coverage.tab"))
	      message(pastte0('Mappability results written to ',input.yaml$output.directory,'/temp/map_coverage.tab  \n'))
              
              foo <- read.table(paste0(input.yaml$output.directory,"/temp/map_coverage.tab"),stringsAsFactors=F)
              exons %>% filter(name %in% (foo %>% filter(V5 >= 0.7) %>% pull(1))) -> exons_1
              exons %>% filter(name %in% (foo %>% filter(V5 < 0.7) %>% pull(1))) -> exons_excluded
              
              exons_1$chromosome <- gsub("chr","",exons_1$chromosome)
              write.table(exons_1[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
              message(paste0('Exons with low mappability written to ',input.yaml$output.directory,'temp/excluded_exons.bed  \n'))
              write.table(exons_excluded,paste0(input.yaml$output.directory,"/temp/excluded_exons.bed"),row.names =F,sep="\t",quote=F,col.names=F)
              exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed")
            }
            
          } else{
            exons <- read.table(input.yaml$bed.file,header = F)
            if (dim(exons)[2] == 3){
              message('Found only 3 columns in ',input.yaml$bed.file,' file. Need 4th Column.\n')
            } else {
              names(exons) <- c("chromosome","start","end","name")
              exons$chromosome <- gsub("chr","",exons$chromosome)
              exons$chromosome <- paste0("chr",exons$chromosome)
              i = 1
              while(length(which(duplicated(exons$name))) >0) {
                exons$name[duplicated(exons$name)] <- paste0( exons$name[duplicated(exons$name)],"_dup",i)
                i = i+1
              }
              write.table(exons,paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F, col.names=F) 
	      system(paste0(bwAvg.exe," ",input.yaml$mappability.file," ",input.yaml$output.directory,"/temp/bed_file.bed ",input.yaml$output.directory,"/temp/map_coverage.tab"))
	      message(pastte0('Mappability results written to ',input.yaml$output.directory,'/temp/map_coverage.tab  \n'))
              
              foo <- read.table(paste0(input.yaml$output.directory,"/temp/map_coverage.tab"),stringsAsFactors=F)
              exons %>% filter(name %in% (foo %>% filter(V5 >= 0.7) %>% pull(1))) -> exons_1
              exons %>% filter(name %in% (foo %>% filter(V5 < 0.7) %>% pull(1))) -> exons_excluded
              
              exons_1$chromosome <- gsub("chr","",exons_1$chromosome)
              write.table(exons_1[,1:3],paste0(input.yaml$output.directory,"/temp/bed_file.bed"),row.names =F,sep="\t",quote=F,col.names=F)
              message(paste0('Exons with low mappability written to ',input.yaml$output.directory,'temp/excluded_exons.bed  \n'))
              write.table(exons_excluded,paste0(input.yaml$output.directory,"/temp/excluded_exons.bed"),row.names =F,sep="\t",quote=F,col.names=F)
              exon_path <- paste0(input.yaml$output.directory,"/temp/bed_file.bed")
            }
          }
        }  
      } else {
        message('Please check mappability file path! The file should have extension .bigWig. Download from here: wget http://hgdownload.cse.ucsc.edu/goldenPath/hg19/encodeDCC/wgEncodeMapability/wgEncodeCrgMapabilityAlign36mer.bigWig ...\n');
      }
    }
  }
}
