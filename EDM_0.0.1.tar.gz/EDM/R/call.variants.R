call.variants <- function(columnIndex,input){
   source("helper_file.R")
#  input.yaml <- yaml::read_yaml("input.yaml")
  cohort.object <- readRDS(paste0(input.yaml$outputDir,"/results/",input.yaml$cohort.name,".exomedepth.cohort.rds"))
 # countmat <- cohort.object[["countmat"]];
  sample_name <- colnames(cohort.object[["countmat"]])[columnIndex];
 # selected.exons <- cohort.object[["selected.exons"]];
 # countmat.cor <- cohort.object[["correlations"]];
 # annotations <- cohort.object[["annotations"]];
  
  reference_list <- select.reference.panel(test.counts = cohort.object[["countmat"]][cohort.object[["selected.exons"]],columnIndex],
                                                 reference.counts = cohort.object[["countmat"]][cohort.object[["selected.exons"]],-columnIndex],
                                                 correlations = cohort.object[["correlations"]][-columnIndex,columnIndex])
  reference_set = apply(
    X = as.matrix(cohort.object[["countmat"]][, reference_list$reference.choice]),
    MAR=1, FUN=sum)
  all_exons = new('ExomeDepth', test=cohort.object[["countmat"]][,columnIndex],
                  reference=reference_set,
                  formula = 'cbind(test,reference) ~ 1')
  all_exons = CallCNVs(x = all_exons, transition.probability=as.numeric(input.yaml$transition.probability),
                       chromosome= cohort.object[["annotations"]]$chromosome, start=cohort.object[["annotations"]]$start,
                       end=cohort.object[["annotations"]]$end, name=cohort.object[["annotations"]]$name)
  
  all_exons@CNV.calls$sample <- sample_name;
  write.table(all_exons@CNV.calls,paste0(input.yaml$outputDir,"/results/",sample_name,".exomedepth.calls.txt"), row.names = F,quote=F)
  saveRDS(all_exons,paste0(input.yaml$outputDir,"/results/",sample_name,".ExomeDepthObject.rds"))
  
  return(all_exons)
}
